---
title: Clipboard2 pulse
categories:
  - Real world
  - Medical
tags:
  - copy
  - paste
  - heartrate
---
