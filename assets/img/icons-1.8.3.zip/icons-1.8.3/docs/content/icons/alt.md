---
title: Alt
categories:
  - UI and keyboard
tags:
  - key
  - alt
  - option
---
