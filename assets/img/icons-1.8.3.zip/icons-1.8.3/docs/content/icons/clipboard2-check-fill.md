---
title: Clipboard2 check fill
categories:
  - Real world
tags:
  - copy
  - paste
---
